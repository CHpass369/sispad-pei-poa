#!/usr/bin/env sh
set -eu

if [ "${AUTO_MAKEMIGRATIONS:-true}" = "true" ]; then
  python manage.py makemigrations --noinput
fi
python manage.py migrate --run-syncdb
python manage.py collectstatic --noinput
python manage.py seed_sispre
exec gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 3 --timeout 120
