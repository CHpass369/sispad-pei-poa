from django.urls import include, path
from rest_framework.routers import DefaultRouter
from apps.catalogs.views import CatalogItemViewSet, OrganizationalUnitViewSet
from apps.projects.views import ProjectViewSet, ProjectComponentViewSet, BeneficiaryGroupViewSet
from apps.preinvestment.views import (
    ITCPViewSet, ITCPConditionViewSet, TDRViewSet, EDTPViewSet,
    EDTPSectionViewSet, TechnicalStudyViewSet, CostItemViewSet,
    FinancingSourceViewSet, EvaluationIndicatorViewSet,
)
from apps.documents.views import DocumentViewSet, GeneratedDocumentViewSet
from apps.workflows.views import ReviewViewSet, ObservationViewSet, ApprovalViewSet
from apps.integrations.views import ExternalReferenceViewSet, OutboxEventViewSet

router = DefaultRouter()
router.register("catalogs", CatalogItemViewSet)
router.register("organizational-units", OrganizationalUnitViewSet)
router.register("projects", ProjectViewSet)
router.register("project-components", ProjectComponentViewSet)
router.register("beneficiary-groups", BeneficiaryGroupViewSet)
router.register("itcps", ITCPViewSet)
router.register("itcp-conditions", ITCPConditionViewSet)
router.register("tdrs", TDRViewSet)
router.register("edtps", EDTPViewSet)
router.register("edtp-sections", EDTPSectionViewSet)
router.register("technical-studies", TechnicalStudyViewSet)
router.register("cost-items", CostItemViewSet)
router.register("financing-sources", FinancingSourceViewSet)
router.register("evaluation-indicators", EvaluationIndicatorViewSet)
router.register("documents", DocumentViewSet)
router.register("generated-documents", GeneratedDocumentViewSet)
router.register("reviews", ReviewViewSet)
router.register("observations", ObservationViewSet)
router.register("approvals", ApprovalViewSet)
router.register("external-references", ExternalReferenceViewSet)
router.register("outbox-events", OutboxEventViewSet)

urlpatterns = [path("", include(router.urls))]
