from rest_framework import serializers
from .models import (
    ITCP, ITCPCondition, TDR, TDRActivity, TDRProduct, TDRPersonnel, TDRBudgetItem,
    EDTP, EDTPSection, TechnicalStudy, CostItem, FinancingSource, ScheduleItem,
    OperationMaintenancePlan, EvaluationIndicator,
)

class ITCPConditionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ITCPCondition
        fields = "__all__"

    def validate(self, attrs):
        if attrs.get("status") == "NOT_APPLICABLE" and not attrs.get("not_applicable_justification"):
            raise serializers.ValidationError("Debe justificar por qué la condición no aplica")
        return attrs

class ITCPSerializer(serializers.ModelSerializer):
    conditions = ITCPConditionSerializer(many=True, read_only=True)
    class Meta:
        model = ITCP
        fields = "__all__"

class TDRActivitySerializer(serializers.ModelSerializer):
    class Meta: model = TDRActivity; fields = "__all__"
class TDRProductSerializer(serializers.ModelSerializer):
    class Meta: model = TDRProduct; fields = "__all__"
class TDRPersonnelSerializer(serializers.ModelSerializer):
    subtotal = serializers.DecimalField(max_digits=18, decimal_places=2, read_only=True)
    class Meta: model = TDRPersonnel; fields = "__all__"
class TDRBudgetItemSerializer(serializers.ModelSerializer):
    subtotal = serializers.DecimalField(max_digits=18, decimal_places=2, read_only=True)
    class Meta: model = TDRBudgetItem; fields = "__all__"
class TDRSerializer(serializers.ModelSerializer):
    activities = TDRActivitySerializer(many=True, read_only=True)
    products = TDRProductSerializer(many=True, read_only=True)
    personnel = TDRPersonnelSerializer(many=True, read_only=True)
    budget_items = TDRBudgetItemSerializer(many=True, read_only=True)
    class Meta: model = TDR; fields = "__all__"

class EDTPSectionSerializer(serializers.ModelSerializer):
    class Meta: model = EDTPSection; fields = "__all__"
    def validate(self, attrs):
        if attrs.get("applicable") is False and not attrs.get("non_applicable_justification"):
            raise serializers.ValidationError("Debe justificar la no aplicabilidad")
        return attrs
class TechnicalStudySerializer(serializers.ModelSerializer):
    class Meta: model = TechnicalStudy; fields = "__all__"
class CostItemSerializer(serializers.ModelSerializer):
    subtotal = serializers.DecimalField(max_digits=24, decimal_places=4, read_only=True)
    class Meta: model = CostItem; fields = "__all__"
class FinancingSourceSerializer(serializers.ModelSerializer):
    class Meta: model = FinancingSource; fields = "__all__"
class EvaluationIndicatorSerializer(serializers.ModelSerializer):
    class Meta: model = EvaluationIndicator; fields = "__all__"
class EDTPSerializer(serializers.ModelSerializer):
    sections = EDTPSectionSerializer(many=True, read_only=True)
    technical_studies = TechnicalStudySerializer(many=True, read_only=True)
    cost_items = CostItemSerializer(many=True, read_only=True)
    financing_sources = FinancingSourceSerializer(many=True, read_only=True)
    evaluation_indicators = EvaluationIndicatorSerializer(many=True, read_only=True)
    class Meta: model = EDTP; fields = "__all__"
