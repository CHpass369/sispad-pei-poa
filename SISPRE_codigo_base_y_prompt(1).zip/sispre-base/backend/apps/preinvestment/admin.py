from django.contrib import admin
from .models import *
for model in [ITCP, ITCPCondition, TDR, TDRActivity, TDRProduct, TDRPersonnel, TDRBudgetItem, EDTP, EDTPSection, TechnicalStudy, CostItem, FinancingSource, ScheduleItem, OperationMaintenancePlan, EvaluationIndicator]:
    admin.site.register(model)
