from django.core.exceptions import ValidationError
from django.db import transaction
from apps.projects.models import ProjectStatus
from .models import ITCP, ITCPCondition, TDR, EDTP, EDTPSection
from .section_catalog import sections_for

ITCP_CONDITIONS = [
    ("JUSTIFICATION", "Justificación y alineamiento normativo", True),
    ("PROJECT_IDEA", "Idea, objetivos, beneficiarios, alternativas y localización", True),
    ("SOCIAL_COMMITMENT", "Compromiso social documentado", True),
    ("PROPERTY", "Estado legal del derecho propietario", True),
    ("THIRD_PARTY", "Derechos de vía y afectación a terceros", True),
    ("ENVIRONMENT", "Posibles impactos ambientales", True),
    ("RISK", "Riesgos de desastre y adaptación al cambio climático", True),
    ("OTHER", "Otros aspectos según complejidad", False),
    ("CONCLUSION", "Conclusiones y recomendaciones", True),
]

@transaction.atomic
def initialize_itcp(project, user=None):
    itcp, created = ITCP.objects.get_or_create(project=project, defaults={"created_by": user})
    if created or not itcp.conditions.exists():
        for order, (category, title, critical) in enumerate(ITCP_CONDITIONS, start=1):
            ITCPCondition.objects.get_or_create(
                itcp=itcp, category=category,
                defaults={"project": project, "title": title, "critical": critical, "order": order, "created_by": user}
            )
    if project.status in [ProjectStatus.REGISTERED, ProjectStatus.ADMITTED]:
        project.status = ProjectStatus.ITCP_DRAFT
        project.save(update_fields=["status", "updated_at"])
    TDR.objects.get_or_create(project=project, defaults={"created_by": user})
    return itcp

@transaction.atomic
def initialize_edtp(project, user=None):
    if not hasattr(project, "itcp") or project.itcp.status != "APPROVED":
        raise ValidationError("El ITCP debe estar aprobado antes de iniciar el EDTP")
    if not hasattr(project, "tdr") or project.tdr.estimated_budget is None:
        raise ValidationError("Se requieren TDR y presupuesto referencial del EDTP")
    edtp, created = EDTP.objects.get_or_create(project=project, defaults={"created_by": user})
    if created or not edtp.sections.exists():
        for order, (code, title, required) in enumerate(sections_for(project.rm115_typology), start=1):
            EDTPSection.objects.get_or_create(
                edtp=edtp, code=code,
                defaults={"title": title, "required": required, "order": order, "created_by": user}
            )
    project.status = ProjectStatus.EDTP_DRAFT
    project.save(update_fields=["status", "updated_at"])
    return edtp

def validate_itcp_for_approval(itcp):
    errors = []
    unresolved = itcp.conditions.filter(critical=True).exclude(status__in=["COMPLIES", "APPROVED", "NOT_APPLICABLE"])
    if unresolved.exists():
        errors.append(f"Existen {unresolved.count()} condiciones críticas sin resolver")
    if not hasattr(itcp.project, "tdr"):
        errors.append("No existe TDR del EDTP")
    elif itcp.project.tdr.estimated_budget is None:
        errors.append("El presupuesto referencial del EDTP no está definido")
    if not itcp.conclusion or not itcp.recommendations:
        errors.append("Conclusiones y recomendaciones son obligatorias")
    return errors

def validate_edtp_for_approval(edtp):
    errors = []
    missing = edtp.sections.filter(required=True, applicable=True).exclude(status="APPROVED")
    if missing.exists():
        errors.append(f"Existen {missing.count()} secciones obligatorias sin aprobar")
    if edtp.technical_studies.filter(required=True).exclude(status="APPROVED").exists():
        errors.append("Existen estudios técnicos obligatorios sin aprobar")
    total_cost = sum((x.subtotal for x in edtp.cost_items.all()), 0)
    total_financing = sum((x.amount for x in edtp.financing_sources.all()), 0)
    if total_cost and abs(total_cost - total_financing) > 0.01:
        errors.append("El costo de inversión no coincide con el financiamiento")
    if hasattr(edtp, "operation_maintenance_plan"):
        om = edtp.operation_maintenance_plan
        if om.annual_operation_cost == 0 and om.annual_maintenance_cost == 0 and not om.zero_cost_justification:
            errors.append("Los costos de operación y mantenimiento están en cero sin justificación")
    return errors
