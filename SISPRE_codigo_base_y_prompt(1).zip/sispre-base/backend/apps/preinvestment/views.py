from django.utils import timezone
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from apps.projects.models import ProjectStatus
from .models import ITCP, ITCPCondition, TDR, EDTP, EDTPSection, TechnicalStudy, CostItem, FinancingSource, EvaluationIndicator
from .serializers import ITCPSerializer, ITCPConditionSerializer, TDRSerializer, EDTPSerializer, EDTPSectionSerializer, TechnicalStudySerializer, CostItemSerializer, FinancingSourceSerializer, EvaluationIndicatorSerializer
from .services import validate_itcp_for_approval, validate_edtp_for_approval

class ITCPViewSet(ModelViewSet):
    queryset = ITCP.objects.select_related("project").prefetch_related("conditions")
    serializer_class = ITCPSerializer
    filterset_fields = ["project", "status"]

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        itcp = self.get_object()
        errors = validate_itcp_for_approval(itcp)
        if errors:
            return Response({"errors": errors}, status=400)
        itcp.status = "APPROVED"
        itcp.approved_at = timezone.now()
        itcp.approved_by = request.user
        itcp.save()
        itcp.project.status = ProjectStatus.ITCP_APPROVED
        itcp.project.save(update_fields=["status", "updated_at"])
        return Response(self.get_serializer(itcp).data)

class ITCPConditionViewSet(ModelViewSet):
    queryset = ITCPCondition.objects.all()
    serializer_class = ITCPConditionSerializer
    filterset_fields = ["project", "itcp", "category", "status", "critical"]

class TDRViewSet(ModelViewSet):
    queryset = TDR.objects.all()
    serializer_class = TDRSerializer
    filterset_fields = ["project", "status"]

class EDTPViewSet(ModelViewSet):
    queryset = EDTP.objects.select_related("project").prefetch_related("sections", "technical_studies", "cost_items", "financing_sources")
    serializer_class = EDTPSerializer
    filterset_fields = ["project", "status", "viability_result"]

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        edtp = self.get_object()
        errors = validate_edtp_for_approval(edtp)
        if errors:
            return Response({"errors": errors}, status=400)
        edtp.status = "APPROVED"
        edtp.approved_at = timezone.now()
        edtp.save()
        edtp.project.status = ProjectStatus.EDTP_APPROVED
        edtp.project.save(update_fields=["status", "updated_at"])
        return Response(self.get_serializer(edtp).data)

class EDTPSectionViewSet(ModelViewSet):
    queryset = EDTPSection.objects.all()
    serializer_class = EDTPSectionSerializer
    filterset_fields = ["edtp", "status", "required", "applicable"]

class TechnicalStudyViewSet(ModelViewSet):
    queryset = TechnicalStudy.objects.all()
    serializer_class = TechnicalStudySerializer
    filterset_fields = ["edtp", "study_type", "status", "required"]

class CostItemViewSet(ModelViewSet):
    queryset = CostItem.objects.all()
    serializer_class = CostItemSerializer
    filterset_fields = ["edtp", "component", "category"]

class FinancingSourceViewSet(ModelViewSet):
    queryset = FinancingSource.objects.all()
    serializer_class = FinancingSourceSerializer
    filterset_fields = ["edtp", "confirmed"]

class EvaluationIndicatorViewSet(ModelViewSet):
    queryset = EvaluationIndicator.objects.all()
    serializer_class = EvaluationIndicatorSerializer
    filterset_fields = ["edtp", "indicator_type"]
