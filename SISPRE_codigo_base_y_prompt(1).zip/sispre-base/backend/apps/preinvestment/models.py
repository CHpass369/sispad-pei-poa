from decimal import Decimal
from django.conf import settings
from django.db import models
from apps.common.models import UUIDTimeStampedModel, SourceTrackedModel
from apps.catalogs.models import OrganizationalUnit
from apps.projects.models import Project, ProjectComponent

class WorkflowStatus(models.TextChoices):
    DRAFT = "DRAFT", "Borrador"
    IN_REVIEW = "IN_REVIEW", "En revisión"
    OBSERVED = "OBSERVED", "Observado"
    APPROVED = "APPROVED", "Aprobado"
    REJECTED = "REJECTED", "Rechazado"

class ConditionStatus(models.TextChoices):
    PENDING = "PENDING", "Pendiente"
    IN_PROGRESS = "IN_PROGRESS", "En elaboración"
    OBSERVED = "OBSERVED", "Observado"
    CORRECTED = "CORRECTED", "Subsanado"
    COMPLIES = "COMPLIES", "Cumple"
    NOT_APPLICABLE = "NOT_APPLICABLE", "No aplica"
    APPROVED = "APPROVED", "Aprobado"

class ITCP(UUIDTimeStampedModel):
    project = models.OneToOneField(Project, on_delete=models.CASCADE, related_name="itcp")
    version = models.PositiveIntegerField(default=1)
    status = models.CharField(max_length=20, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT)
    initiative_justification = models.TextField(blank=True)
    project_idea = models.TextField(blank=True)
    preliminary_result = models.CharField(max_length=40, choices=[
        ("VIABLE_FOR_EDTP", "Viable para elaborar EDTP"),
        ("VIABLE_WITH_CONDITIONS", "Viable con condiciones"),
        ("NOT_VIABLE", "No viable"),
        ("INSUFFICIENT_INFORMATION", "Información insuficiente"),
    ], blank=True)
    conclusion = models.TextField(blank=True)
    recommendations = models.TextField(blank=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="approved_itcps")

class ITCPCondition(UUIDTimeStampedModel, SourceTrackedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="itcp_conditions")
    itcp = models.ForeignKey(ITCP, on_delete=models.CASCADE, related_name="conditions")
    category = models.CharField(max_length=50, choices=[
        ("JUSTIFICATION", "Justificación y alineamiento"),
        ("PROJECT_IDEA", "Idea del proyecto"),
        ("SOCIAL_COMMITMENT", "Compromiso social"),
        ("PROPERTY", "Derecho propietario"),
        ("THIRD_PARTY", "Derechos de vía y terceros"),
        ("ENVIRONMENT", "Impactos ambientales"),
        ("RISK", "Riesgos y cambio climático"),
        ("OTHER", "Otros aspectos"),
        ("CONCLUSION", "Conclusiones y recomendaciones"),
    ])
    title = models.CharField(max_length=255)
    status = models.CharField(max_length=25, choices=ConditionStatus.choices, default=ConditionStatus.PENDING)
    finding = models.TextField(blank=True)
    action_plan = models.TextField(blank=True)
    not_applicable_justification = models.TextField(blank=True)
    responsible_unit = models.ForeignKey(OrganizationalUnit, null=True, blank=True, on_delete=models.PROTECT)
    due_date = models.DateField(null=True, blank=True)
    critical = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0)

class TDR(UUIDTimeStampedModel):
    project = models.OneToOneField(Project, on_delete=models.CASCADE, related_name="tdr")
    version = models.PositiveIntegerField(default=1)
    status = models.CharField(max_length=20, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT)
    justification = models.TextField(blank=True)
    objectives = models.TextField(blank=True)
    scope = models.TextField(blank=True)
    actors_responsibilities = models.TextField(blank=True)
    methodology = models.TextField(blank=True)
    duration_days = models.PositiveIntegerField(null=True, blank=True)
    estimated_budget = models.DecimalField(max_digits=18, decimal_places=2, null=True, blank=True)

class TDRActivity(UUIDTimeStampedModel):
    tdr = models.ForeignKey(TDR, on_delete=models.CASCADE, related_name="activities")
    code = models.CharField(max_length=30)
    description = models.TextField()
    duration_days = models.PositiveIntegerField(default=0)
    order = models.PositiveIntegerField(default=0)

class TDRProduct(UUIDTimeStampedModel):
    tdr = models.ForeignKey(TDR, on_delete=models.CASCADE, related_name="products")
    code = models.CharField(max_length=30)
    name = models.CharField(max_length=255)
    acceptance_criteria = models.TextField(blank=True)
    due_day = models.PositiveIntegerField(default=0)

class TDRPersonnel(UUIDTimeStampedModel):
    tdr = models.ForeignKey(TDR, on_delete=models.CASCADE, related_name="personnel")
    role = models.CharField(max_length=255)
    quantity = models.PositiveIntegerField(default=1)
    months = models.DecimalField(max_digits=8, decimal_places=2, default=1)
    dedication_percent = models.DecimalField(max_digits=5, decimal_places=2, default=100)
    monthly_rate = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    requirements = models.TextField(blank=True)

    @property
    def subtotal(self):
        return self.quantity * self.months * (self.dedication_percent / Decimal("100")) * self.monthly_rate

class TDRBudgetItem(UUIDTimeStampedModel):
    tdr = models.ForeignKey(TDR, on_delete=models.CASCADE, related_name="budget_items")
    category = models.CharField(max_length=80)
    description = models.CharField(max_length=255)
    quantity = models.DecimalField(max_digits=18, decimal_places=4, default=1)
    unit = models.CharField(max_length=40, default="global")
    unit_cost = models.DecimalField(max_digits=18, decimal_places=2, default=0)

    @property
    def subtotal(self):
        return self.quantity * self.unit_cost

class EDTP(UUIDTimeStampedModel):
    project = models.OneToOneField(Project, on_delete=models.CASCADE, related_name="edtp")
    version = models.PositiveIntegerField(default=1)
    status = models.CharField(max_length=20, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT)
    executive_summary = models.TextField(blank=True)
    evaluation_method = models.CharField(max_length=40, blank=True)
    viability_result = models.CharField(max_length=40, choices=[
        ("VIABLE", "Viable"), ("VIABLE_WITH_CONDITIONS", "Viable con condiciones"),
        ("NOT_VIABLE", "No viable"), ("SUSPENDED", "Suspendido")
    ], blank=True)
    conclusion = models.TextField(blank=True)
    recommendations = models.TextField(blank=True)
    approved_at = models.DateTimeField(null=True, blank=True)

class EDTPSection(UUIDTimeStampedModel, SourceTrackedModel):
    edtp = models.ForeignKey(EDTP, on_delete=models.CASCADE, related_name="sections")
    code = models.CharField(max_length=30)
    title = models.CharField(max_length=255)
    order = models.PositiveIntegerField(default=0)
    required = models.BooleanField(default=True)
    applicable = models.BooleanField(default=True)
    non_applicable_justification = models.TextField(blank=True)
    content = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT)
    completion_percent = models.PositiveSmallIntegerField(default=0)
    validation_errors = models.JSONField(default=list, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["edtp", "code"], name="uniq_edtp_section")]
        ordering = ["order", "code"]

class TechnicalStudy(UUIDTimeStampedModel):
    edtp = models.ForeignKey(EDTP, on_delete=models.CASCADE, related_name="technical_studies")
    study_type = models.CharField(max_length=80)
    title = models.CharField(max_length=255)
    required = models.BooleanField(default=True)
    status = models.CharField(max_length=20, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT)
    professional_name = models.CharField(max_length=255, blank=True)
    professional_registration = models.CharField(max_length=100, blank=True)
    study_date = models.DateField(null=True, blank=True)
    version = models.PositiveIntegerField(default=1)
    conclusions = models.TextField(blank=True)

class CostItem(UUIDTimeStampedModel, SourceTrackedModel):
    edtp = models.ForeignKey(EDTP, on_delete=models.CASCADE, related_name="cost_items")
    component = models.ForeignKey(ProjectComponent, null=True, blank=True, on_delete=models.PROTECT, related_name="cost_items")
    category = models.CharField(max_length=80)
    code = models.CharField(max_length=50)
    description = models.CharField(max_length=500)
    unit = models.CharField(max_length=40)
    quantity = models.DecimalField(max_digits=18, decimal_places=4)
    unit_price = models.DecimalField(max_digits=18, decimal_places=4)

    @property
    def subtotal(self):
        return self.quantity * self.unit_price

class FinancingSource(UUIDTimeStampedModel):
    edtp = models.ForeignKey(EDTP, on_delete=models.CASCADE, related_name="financing_sources")
    source_code = models.CharField(max_length=80)
    source_name = models.CharField(max_length=255)
    amount = models.DecimalField(max_digits=18, decimal_places=2)
    confirmed = models.BooleanField(default=False)

class ScheduleItem(UUIDTimeStampedModel):
    edtp = models.ForeignKey(EDTP, on_delete=models.CASCADE, related_name="schedule_items")
    component = models.ForeignKey(ProjectComponent, null=True, blank=True, on_delete=models.PROTECT)
    name = models.CharField(max_length=255)
    start_date = models.DateField()
    end_date = models.DateField()
    planned_amount = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    physical_weight = models.DecimalField(max_digits=7, decimal_places=4, default=0)

class OperationMaintenancePlan(UUIDTimeStampedModel):
    edtp = models.OneToOneField(EDTP, on_delete=models.CASCADE, related_name="operation_maintenance_plan")
    operator = models.CharField(max_length=255, blank=True)
    activities = models.TextField(blank=True)
    annual_operation_cost = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    annual_maintenance_cost = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    funding_mechanism = models.TextField(blank=True)
    zero_cost_justification = models.TextField(blank=True)

class EvaluationIndicator(UUIDTimeStampedModel, SourceTrackedModel):
    edtp = models.ForeignKey(EDTP, on_delete=models.CASCADE, related_name="evaluation_indicators")
    indicator_type = models.CharField(max_length=80)
    name = models.CharField(max_length=255)
    value = models.DecimalField(max_digits=24, decimal_places=6)
    unit = models.CharField(max_length=80, blank=True)
    interpretation = models.TextField(blank=True)
