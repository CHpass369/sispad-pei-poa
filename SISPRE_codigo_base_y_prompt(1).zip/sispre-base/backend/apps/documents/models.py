import hashlib
from django.db import models
from apps.common.models import UUIDTimeStampedModel
from apps.projects.models import Project

class Document(UUIDTimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="documents")
    document_type = models.CharField(max_length=80)
    title = models.CharField(max_length=500)
    stage = models.CharField(max_length=50, blank=True)
    status = models.CharField(max_length=30, default="DRAFT")
    current_version = models.PositiveIntegerField(default=1)
    metadata = models.JSONField(default=dict, blank=True)

class DocumentVersion(UUIDTimeStampedModel):
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="versions")
    version = models.PositiveIntegerField()
    file = models.FileField(upload_to="documents/%Y/%m/")
    file_name = models.CharField(max_length=500)
    mime_type = models.CharField(max_length=120, blank=True)
    sha256 = models.CharField(max_length=64, blank=True)
    signed = models.BooleanField(default=False)
    notes = models.TextField(blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["document", "version"], name="uniq_document_version")]

    def calculate_hash(self):
        digest = hashlib.sha256()
        for chunk in self.file.chunks():
            digest.update(chunk)
        self.sha256 = digest.hexdigest()
        return self.sha256

class GeneratedDocument(UUIDTimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="generated_documents")
    document_type = models.CharField(max_length=20)
    status = models.CharField(max_length=30, default="QUEUED")
    template_name = models.CharField(max_length=255, blank=True)
    output_file = models.FileField(upload_to="generated/%Y/%m/", null=True, blank=True)
    pdf_file = models.FileField(upload_to="generated/%Y/%m/", null=True, blank=True)
    error_message = models.TextField(blank=True)
    context_snapshot = models.JSONField(default=dict, blank=True)
