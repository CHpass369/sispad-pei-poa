from rest_framework import serializers
from .models import Document, DocumentVersion, GeneratedDocument
class DocumentVersionSerializer(serializers.ModelSerializer):
    class Meta: model = DocumentVersion; fields = "__all__"
class DocumentSerializer(serializers.ModelSerializer):
    versions = DocumentVersionSerializer(many=True, read_only=True)
    class Meta: model = Document; fields = "__all__"
class GeneratedDocumentSerializer(serializers.ModelSerializer):
    class Meta: model = GeneratedDocument; fields = "__all__"
