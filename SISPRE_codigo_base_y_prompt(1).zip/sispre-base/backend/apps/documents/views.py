from rest_framework.viewsets import ModelViewSet, ReadOnlyModelViewSet
from .models import Document, GeneratedDocument
from .serializers import DocumentSerializer, GeneratedDocumentSerializer
class DocumentViewSet(ModelViewSet):
    queryset = Document.objects.prefetch_related("versions")
    serializer_class = DocumentSerializer
    filterset_fields = ["project", "document_type", "stage", "status"]
class GeneratedDocumentViewSet(ReadOnlyModelViewSet):
    queryset = GeneratedDocument.objects.all()
    serializer_class = GeneratedDocumentSerializer
    filterset_fields = ["project", "document_type", "status"]
