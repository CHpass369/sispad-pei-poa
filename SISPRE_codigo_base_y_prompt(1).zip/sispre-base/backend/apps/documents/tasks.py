from celery import shared_task
from django.contrib.auth import get_user_model
from apps.projects.models import Project
from .models import GeneratedDocument
from .services import generate_document

@shared_task(bind=True)
def generate_project_document(self, project_id, document_type, user_id=None):
    project = Project.objects.get(id=project_id)
    user = get_user_model().objects.filter(id=user_id).first()
    generated = GeneratedDocument.objects.create(project=project, document_type=document_type, created_by=user)
    result = generate_document(project, document_type, generated)
    return {"generated_document_id": str(result.id), "status": result.status}
