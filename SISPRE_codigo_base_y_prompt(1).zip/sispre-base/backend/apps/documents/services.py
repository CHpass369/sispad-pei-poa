from pathlib import Path
import json
import subprocess
import tempfile
from django.conf import settings
from django.core.files import File
from docxtpl import DocxTemplate
from .models import GeneratedDocument

class DocumentGenerationError(RuntimeError):
    pass

def build_context(project, document_type):
    context = {
        "project": {
            "code": project.code,
            "official_name": project.official_name,
            "management_year": project.management_year,
            "typology": project.get_rm115_typology_display() if project.rm115_typology else "",
            "district": project.district_code,
            "community": project.community_name,
            "problem": project.problem_statement,
            "objective": project.general_objective,
            "budget": str(project.approved_budget or project.estimated_budget or ""),
        },
        "components": list(project.components.values("code", "name", "description", "physical_target", "unit", "budget")),
        "beneficiaries": list(project.beneficiary_groups.values("group_type", "description", "quantity", "unit", "source_name", "source_date")),
    }
    if document_type == "ITCP":
        if not hasattr(project, "itcp"):
            raise DocumentGenerationError("El proyecto no tiene ITCP")
        context["itcp"] = {
            "version": project.itcp.version,
            "justification": project.itcp.initiative_justification,
            "idea": project.itcp.project_idea,
            "result": project.itcp.get_preliminary_result_display() if project.itcp.preliminary_result else "",
            "conclusion": project.itcp.conclusion,
            "recommendations": project.itcp.recommendations,
            "conditions": list(project.itcp.conditions.order_by("order").values("title", "status", "finding", "action_plan", "source_name", "source_reference")),
        }
        if hasattr(project, "tdr"):
            context["tdr"] = {
                "objectives": project.tdr.objectives,
                "scope": project.tdr.scope,
                "methodology": project.tdr.methodology,
                "duration_days": project.tdr.duration_days,
                "estimated_budget": str(project.tdr.estimated_budget or ""),
            }
    else:
        if not hasattr(project, "edtp"):
            raise DocumentGenerationError("El proyecto no tiene EDTP")
        context["edtp"] = {
            "version": project.edtp.version,
            "summary": project.edtp.executive_summary,
            "evaluation_method": project.edtp.evaluation_method,
            "viability_result": project.edtp.get_viability_result_display() if project.edtp.viability_result else "",
            "conclusion": project.edtp.conclusion,
            "recommendations": project.edtp.recommendations,
            "sections": list(project.edtp.sections.order_by("order").values("code", "title", "content", "source_name", "source_date", "source_reference")),
            "studies": list(project.edtp.technical_studies.values("study_type", "title", "status", "professional_name", "professional_registration", "study_date", "conclusions")),
            "cost_items": [
                {"code": item.code, "description": item.description, "unit": item.unit, "quantity": str(item.quantity), "unit_price": str(item.unit_price), "subtotal": str(item.subtotal)}
                for item in project.edtp.cost_items.all()
            ],
            "financing": list(project.edtp.financing_sources.values("source_code", "source_name", "amount", "confirmed")),
        }
    return context

def select_template(project, document_type):
    if document_type == "ITCP":
        return settings.DOCUMENT_TEMPLATE_DIR / "itcp_base.docx"
    if project.rm115_typology in {"IV", "V"}:
        return settings.DOCUMENT_TEMPLATE_DIR / "edtp_institutional.docx"
    return settings.DOCUMENT_TEMPLATE_DIR / "edtp_base.docx"

def generate_document(project, document_type, generated=None):
    template_path = select_template(project, document_type)
    if not template_path.exists():
        raise DocumentGenerationError(f"No existe plantilla: {template_path}")
    context = build_context(project, document_type)
    generated = generated or GeneratedDocument.objects.create(project=project, document_type=document_type)
    generated.status = "PROCESSING"
    generated.template_name = template_path.name
    generated.context_snapshot = json.loads(json.dumps(context, default=str))
    generated.save()
    try:
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / f"{project.code}_{document_type}_v1.docx"
            tpl = DocxTemplate(template_path)
            tpl.render(context)
            tpl.save(output)
            with output.open("rb") as fh:
                generated.output_file.save(output.name, File(fh), save=False)
            # Conversión opcional a PDF; no bloquea DOCX si LibreOffice falla.
            try:
                subprocess.run([
                    "libreoffice", "--headless", "--convert-to", "pdf", "--outdir", tmp, str(output)
                ], check=True, capture_output=True, timeout=120)
                pdf = output.with_suffix(".pdf")
                if pdf.exists():
                    with pdf.open("rb") as fh:
                        generated.pdf_file.save(pdf.name, File(fh), save=False)
            except Exception as exc:
                generated.error_message = f"DOCX generado; PDF pendiente: {exc}"
        generated.status = "COMPLETED"
        generated.save()
        return generated
    except Exception as exc:
        generated.status = "FAILED"
        generated.error_message = str(exc)
        generated.save()
        raise
