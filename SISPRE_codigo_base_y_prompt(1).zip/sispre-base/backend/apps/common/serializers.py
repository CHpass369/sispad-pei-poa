from rest_framework import serializers

class GeoJSONGeometryField(serializers.Field):
    def to_representation(self, value):
        if not value:
            return None
        return value.geojson

    def to_internal_value(self, data):
        from django.contrib.gis.geos import GEOSGeometry
        if data in (None, ""):
            return None
        try:
            return GEOSGeometry(str(data) if isinstance(data, str) else __import__('json').dumps(data), srid=4326)
        except Exception as exc:
            raise serializers.ValidationError(f"Geometría inválida: {exc}") from exc
