import uuid
from django.conf import settings
from django.db import models

class UUIDTimeStampedModel(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
        related_name="created_%(class)ss"
    )
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
        related_name="updated_%(class)ss"
    )

    class Meta:
        abstract = True

class SourceTrackedModel(models.Model):
    source_name = models.CharField(max_length=255, blank=True)
    source_date = models.DateField(null=True, blank=True)
    source_reference = models.CharField(max_length=500, blank=True)
    source_metadata = models.JSONField(default=dict, blank=True)

    class Meta:
        abstract = True
