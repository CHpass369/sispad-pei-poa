from rest_framework.permissions import BasePermission, SAFE_METHODS

class ProjectScopedPermission(BasePermission):
    """Base simple: lectura autenticada; escritura para staff o responsables/unidad asignada."""
    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        if request.user.is_staff:
            return True
        project = getattr(obj, "project", obj)
        return getattr(project, "responsible_id", None) == request.user.id
