from .models import AuditEvent
class AuditContextMiddleware:
    def __init__(self, get_response): self.get_response = get_response
    def __call__(self, request):
        response = self.get_response(request)
        if request.path.startswith("/api/") and request.method not in {"GET", "HEAD", "OPTIONS"}:
            try:
                AuditEvent.objects.create(
                    user=request.user if getattr(request, "user", None) and request.user.is_authenticated else None,
                    action="API_MUTATION", method=request.method, path=request.path,
                    ip_address=request.META.get("REMOTE_ADDR"), metadata={"status_code": response.status_code}
                )
            except Exception:
                pass
        return response
