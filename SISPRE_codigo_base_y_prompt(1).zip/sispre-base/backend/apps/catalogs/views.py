from rest_framework.viewsets import ModelViewSet
from .models import CatalogItem, OrganizationalUnit
from .serializers import CatalogItemSerializer, OrganizationalUnitSerializer

class CatalogItemViewSet(ModelViewSet):
    queryset = CatalogItem.objects.all()
    serializer_class = CatalogItemSerializer
    filterset_fields = ["catalog_type", "code", "active"]
    search_fields = ["code", "name", "description"]

class OrganizationalUnitViewSet(ModelViewSet):
    queryset = OrganizationalUnit.objects.all()
    serializer_class = OrganizationalUnitSerializer
    filterset_fields = ["active", "parent"]
    search_fields = ["code", "name"]
