from django.contrib import admin
from .models import CatalogItem, OrganizationalUnit
admin.site.register(CatalogItem)
admin.site.register(OrganizationalUnit)
