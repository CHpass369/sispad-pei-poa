from django.core.management.base import BaseCommand
from apps.catalogs.models import CatalogItem

DATA = {
    "RM115_TYPOLOGY": [
        ("I", "Desarrollo Empresarial Productivo"),
        ("II", "Apoyo al Desarrollo Productivo"),
        ("III", "Desarrollo Social"),
        ("IV", "Fortalecimiento Institucional"),
        ("V", "Investigación y Desarrollo Tecnológico"),
    ],
    "PROJECT_STATUS": [
        ("REGISTERED", "Iniciativa registrada"), ("ADMITTED", "Admitida"),
        ("ITCP_DRAFT", "ITCP en elaboración"), ("ITCP_APPROVED", "ITCP aprobado"),
        ("EDTP_DRAFT", "EDTP en elaboración"), ("EDTP_APPROVED", "EDTP aprobado"),
        ("ELIGIBLE_POA", "Habilitado para programación"),
    ],
    "PROJECT_CLASS": [
        ("RETAINING_WALL", "Muro de contención"), ("BRIDGE", "Puente"),
        ("WATER_WELL", "Pozo de agua"), ("EDUCATION_INFRA", "Infraestructura educativa"),
        ("ROAD", "Infraestructura vial"), ("WATER_SANITATION", "Agua y saneamiento"),
        ("INSTITUTIONAL_SYSTEM", "Sistema institucional"),
    ],
}

class Command(BaseCommand):
    help = "Carga catálogos base de forma idempotente"
    def handle(self, *args, **options):
        total = 0
        for catalog_type, items in DATA.items():
            for order, (code, name) in enumerate(items, start=1):
                _, created = CatalogItem.objects.update_or_create(
                    catalog_type=catalog_type, code=code,
                    defaults={"name": name, "order": order, "active": True}
                )
                total += int(created)
        self.stdout.write(self.style.SUCCESS(f"Catálogos listos. Nuevos: {total}"))
