from rest_framework import serializers
from .models import CatalogItem, OrganizationalUnit

class CatalogItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = CatalogItem
        fields = "__all__"
        read_only_fields = ("id", "created_at", "updated_at")

class OrganizationalUnitSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrganizationalUnit
        fields = "__all__"
        read_only_fields = ("id", "created_at", "updated_at")
