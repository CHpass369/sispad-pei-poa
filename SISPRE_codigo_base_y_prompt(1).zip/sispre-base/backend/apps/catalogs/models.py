from django.db import models
from apps.common.models import UUIDTimeStampedModel

class CatalogItem(UUIDTimeStampedModel):
    catalog_type = models.CharField(max_length=80, db_index=True)
    code = models.CharField(max_length=80)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    active = models.BooleanField(default=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["catalog_type", "code"], name="uniq_catalog_code")]
        ordering = ["catalog_type", "order", "name"]

    def __str__(self):
        return f"{self.catalog_type}:{self.code} - {self.name}"

class OrganizationalUnit(UUIDTimeStampedModel):
    code = models.CharField(max_length=80, unique=True)
    name = models.CharField(max_length=255)
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.PROTECT, related_name="children")
    active = models.BooleanField(default=True)
    external_codes = models.JSONField(default=dict, blank=True)

    def __str__(self):
        return self.name
