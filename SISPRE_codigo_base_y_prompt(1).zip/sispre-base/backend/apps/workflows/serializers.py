from rest_framework import serializers
from .models import Review, Observation, Approval
class ReviewSerializer(serializers.ModelSerializer):
    class Meta: model = Review; fields = "__all__"
class ObservationSerializer(serializers.ModelSerializer):
    class Meta: model = Observation; fields = "__all__"
class ApprovalSerializer(serializers.ModelSerializer):
    class Meta: model = Approval; fields = "__all__"
