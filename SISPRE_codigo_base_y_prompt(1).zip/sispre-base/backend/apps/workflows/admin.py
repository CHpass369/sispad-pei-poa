from django.contrib import admin
from .models import Review, Observation, Approval
admin.site.register(Review); admin.site.register(Observation); admin.site.register(Approval)
