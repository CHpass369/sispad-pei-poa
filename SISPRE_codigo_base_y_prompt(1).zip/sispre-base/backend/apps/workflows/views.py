from rest_framework.viewsets import ModelViewSet
from .models import Review, Observation, Approval
from .serializers import ReviewSerializer, ObservationSerializer, ApprovalSerializer
class ReviewViewSet(ModelViewSet):
    queryset = Review.objects.all(); serializer_class = ReviewSerializer
    filterset_fields = ["project", "stage", "review_type", "status"]
class ObservationViewSet(ModelViewSet):
    queryset = Observation.objects.all(); serializer_class = ObservationSerializer
    filterset_fields = ["project", "review", "severity", "status"]
class ApprovalViewSet(ModelViewSet):
    queryset = Approval.objects.all(); serializer_class = ApprovalSerializer
    filterset_fields = ["project", "stage", "approval_level", "status"]
