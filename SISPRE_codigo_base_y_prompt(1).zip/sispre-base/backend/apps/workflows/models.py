from django.conf import settings
from django.db import models
from apps.common.models import UUIDTimeStampedModel
from apps.projects.models import Project
from apps.catalogs.models import OrganizationalUnit

class Review(UUIDTimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="reviews")
    stage = models.CharField(max_length=40)
    review_type = models.CharField(max_length=50)
    assigned_unit = models.ForeignKey(OrganizationalUnit, null=True, blank=True, on_delete=models.PROTECT)
    assigned_user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    status = models.CharField(max_length=30, default="PENDING")
    due_date = models.DateField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

class Observation(UUIDTimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="observations")
    review = models.ForeignKey(Review, null=True, blank=True, on_delete=models.CASCADE, related_name="observations")
    code = models.CharField(max_length=40)
    section_reference = models.CharField(max_length=120, blank=True)
    severity = models.CharField(max_length=20, choices=[("LOW", "Baja"), ("MEDIUM", "Media"), ("HIGH", "Alta"), ("CRITICAL", "Crítica")])
    description = models.TextField()
    status = models.CharField(max_length=20, default="OPEN")
    response = models.TextField(blank=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

class Approval(UUIDTimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="approvals")
    stage = models.CharField(max_length=40)
    approval_level = models.CharField(max_length=80)
    approver = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    status = models.CharField(max_length=20, default="PENDING")
    decision_date = models.DateTimeField(null=True, blank=True)
    comments = models.TextField(blank=True)
    instrument_number = models.CharField(max_length=120, blank=True)
