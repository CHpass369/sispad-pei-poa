from rest_framework.viewsets import ModelViewSet, ReadOnlyModelViewSet
from .models import ExternalReference, OutboxEvent
from .serializers import ExternalReferenceSerializer, OutboxEventSerializer
class ExternalReferenceViewSet(ModelViewSet):
    queryset = ExternalReference.objects.all(); serializer_class = ExternalReferenceSerializer
    filterset_fields = ["project", "system"]
class OutboxEventViewSet(ReadOnlyModelViewSet):
    queryset = OutboxEvent.objects.all(); serializer_class = OutboxEventSerializer
    filterset_fields = ["event_type", "status", "aggregate_type"]
