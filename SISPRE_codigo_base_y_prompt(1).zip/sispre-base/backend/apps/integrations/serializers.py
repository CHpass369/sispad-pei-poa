from rest_framework import serializers
from .models import ExternalReference, OutboxEvent
class ExternalReferenceSerializer(serializers.ModelSerializer):
    class Meta: model = ExternalReference; fields = "__all__"
class OutboxEventSerializer(serializers.ModelSerializer):
    class Meta: model = OutboxEvent; fields = "__all__"; read_only_fields = ("event_id", "attempts", "published_at")
