import uuid
from django.db import models
from apps.common.models import UUIDTimeStampedModel
from apps.projects.models import Project

class ExternalReference(UUIDTimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="external_references")
    system = models.CharField(max_length=40)
    external_id = models.CharField(max_length=255)
    external_code = models.CharField(max_length=255, blank=True)
    last_sync_at = models.DateTimeField(null=True, blank=True)
    metadata = models.JSONField(default=dict, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["system", "external_id"], name="uniq_external_reference")]

class OutboxEvent(UUIDTimeStampedModel):
    event_id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    aggregate_type = models.CharField(max_length=80)
    aggregate_id = models.UUIDField()
    event_type = models.CharField(max_length=120)
    payload = models.JSONField(default=dict)
    status = models.CharField(max_length=20, default="PENDING")
    attempts = models.PositiveIntegerField(default=0)
    published_at = models.DateTimeField(null=True, blank=True)
    last_error = models.TextField(blank=True)

class InboundMessage(UUIDTimeStampedModel):
    source_system = models.CharField(max_length=40)
    idempotency_key = models.CharField(max_length=255, unique=True)
    message_type = models.CharField(max_length=120)
    payload = models.JSONField(default=dict)
    processed = models.BooleanField(default=False)
    error = models.TextField(blank=True)
