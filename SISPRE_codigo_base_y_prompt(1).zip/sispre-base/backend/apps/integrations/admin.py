from django.contrib import admin
from .models import ExternalReference, OutboxEvent, InboundMessage
admin.site.register(ExternalReference); admin.site.register(OutboxEvent); admin.site.register(InboundMessage)
