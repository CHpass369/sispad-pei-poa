from django.contrib.gis.geos import GEOSGeometry

def build_transfer_package(project):
    geom = None
    if project.geom:
        geom = __import__('json').loads(project.geom.transform(4326, clone=True).geojson)
    package = {
        "schema_version": "1.0",
        "project_id": str(project.id),
        "project_code": project.code,
        "official_name": project.official_name,
        "management_year": project.management_year,
        "status": project.status,
        "rm115_typology": project.rm115_typology,
        "district_code": project.district_code,
        "community_name": project.community_name,
        "geometry": geom,
        "problem_statement": project.problem_statement,
        "general_objective": project.general_objective,
        "approved_budget": str(project.approved_budget or ""),
        "currency": project.currency,
        "readiness_score": str(project.readiness_score),
        "components": [
            {"id": str(c.id), "code": c.code, "name": c.name, "target": str(c.physical_target or ""), "unit": c.unit, "budget": str(c.budget)}
            for c in project.components.all()
        ],
        "beneficiaries": [
            {"type": b.group_type, "description": b.description, "quantity": b.quantity, "unit": b.unit}
            for b in project.beneficiary_groups.all()
        ],
        "documents": [
            {"id": str(d.id), "type": d.document_type, "title": d.title, "status": d.status, "version": d.current_version}
            for d in project.documents.all()
        ],
    }
    if hasattr(project, "edtp"):
        package["edtp"] = {
            "version": project.edtp.version,
            "viability_result": project.edtp.viability_result,
            "evaluation_method": project.edtp.evaluation_method,
            "financing": [{"code": f.source_code, "name": f.source_name, "amount": str(f.amount), "confirmed": f.confirmed} for f in project.edtp.financing_sources.all()],
        }
    return package
