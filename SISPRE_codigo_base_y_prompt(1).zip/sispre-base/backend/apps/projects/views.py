from django.db import transaction
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from apps.common.permissions import ProjectScopedPermission
from apps.preinvestment.services import initialize_itcp, initialize_edtp
from apps.documents.tasks import generate_project_document
from apps.integrations.services import build_transfer_package
from .models import Project, ProjectComponent, BeneficiaryGroup, ReformulationRequest
from .serializers import ProjectSerializer, ProjectComponentSerializer, BeneficiaryGroupSerializer, ReformulationRequestSerializer
from .services import suggest_typology, calculate_readiness

class ProjectViewSet(ModelViewSet):
    queryset = Project.objects.select_related("responsible", "requesting_unit", "formulating_unit").prefetch_related("components", "beneficiary_groups")
    serializer_class = ProjectSerializer
    permission_classes = [ProjectScopedPermission]
    filterset_fields = ["status", "management_year", "rm115_typology", "district_code", "eligible_for_poa"]
    search_fields = ["code", "official_name", "short_name", "community_name"]
    ordering_fields = ["created_at", "updated_at", "readiness_score", "approved_budget"]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)

    @action(detail=True, methods=["post"])
    def classify(self, request, pk=None):
        project = self.get_object()
        suggested = suggest_typology(project)
        if request.data.get("accept", True):
            project.rm115_typology = suggested
            project.save(update_fields=["rm115_typology", "updated_at"])
        return Response({"suggested_typology": suggested, "accepted": request.data.get("accept", True)})

    @action(detail=True, methods=["post"], url_path="initialize-itcp")
    def initialize_itcp_action(self, request, pk=None):
        itcp = initialize_itcp(self.get_object(), request.user)
        return Response({"itcp_id": itcp.id, "conditions": itcp.conditions.count()}, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"], url_path="initialize-edtp")
    def initialize_edtp_action(self, request, pk=None):
        edtp = initialize_edtp(self.get_object(), request.user)
        return Response({"edtp_id": edtp.id, "sections": edtp.sections.count()}, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"], url_path="calculate-readiness")
    def calculate_readiness_action(self, request, pk=None):
        project = self.get_object()
        score = calculate_readiness(project)
        return Response({"score": score, "eligible_for_poa": project.eligible_for_poa, "status": project.status})

    @action(detail=True, methods=["post"], url_path="generate-document")
    def generate_document_action(self, request, pk=None):
        document_type = request.data.get("document_type")
        if document_type not in {"ITCP", "EDTP"}:
            return Response({"detail": "document_type debe ser ITCP o EDTP"}, status=400)
        task = generate_project_document.delay(str(self.get_object().id), document_type, request.user.id)
        return Response({"task_id": task.id, "status": "QUEUED"}, status=202)

    @action(detail=True, methods=["get"], url_path="transfer-package")
    def transfer_package(self, request, pk=None):
        return Response(build_transfer_package(self.get_object()))

    @action(detail=True, methods=["post"], url_path="request-reformulation")
    def request_reformulation(self, request, pk=None):
        serializer = ReformulationRequestSerializer(data={**request.data, "project": pk})
        serializer.is_valid(raise_exception=True)
        serializer.save(created_by=request.user)
        return Response(serializer.data, status=201)

    @action(detail=False, methods=["get"], url_path="eligible-for-poa")
    def eligible_for_poa(self, request):
        qs = self.filter_queryset(self.get_queryset().filter(eligible_for_poa=True))
        return Response(self.get_serializer(qs, many=True).data)

class ProjectComponentViewSet(ModelViewSet):
    queryset = ProjectComponent.objects.all()
    serializer_class = ProjectComponentSerializer
    filterset_fields = ["project"]

class BeneficiaryGroupViewSet(ModelViewSet):
    queryset = BeneficiaryGroup.objects.all()
    serializer_class = BeneficiaryGroupSerializer
    filterset_fields = ["project", "group_type"]
