from django.contrib import admin
from .models import Project, ProjectComponent, BeneficiaryGroup, ProjectAlternative, ReformulationRequest
for model in [Project, ProjectComponent, BeneficiaryGroup, ProjectAlternative, ReformulationRequest]:
    admin.site.register(model)
