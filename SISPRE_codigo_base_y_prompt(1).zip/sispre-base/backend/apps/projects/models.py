from decimal import Decimal
from django.conf import settings
from django.contrib.gis.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from apps.common.models import UUIDTimeStampedModel, SourceTrackedModel
from apps.catalogs.models import CatalogItem, OrganizationalUnit

class ProjectStatus(models.TextChoices):
    REGISTERED = "REGISTERED", "Iniciativa registrada"
    ADMISSION = "ADMISSION", "En admisibilidad"
    ADMITTED = "ADMITTED", "Admitida"
    ITCP_DRAFT = "ITCP_DRAFT", "ITCP en elaboración"
    ITCP_REVIEW = "ITCP_REVIEW", "ITCP en revisión"
    ITCP_APPROVED = "ITCP_APPROVED", "ITCP aprobado"
    EDTP_DRAFT = "EDTP_DRAFT", "EDTP en elaboración"
    EDTP_REVIEW = "EDTP_REVIEW", "EDTP en revisión"
    EDTP_APPROVED = "EDTP_APPROVED", "EDTP aprobado"
    VIABLE = "VIABLE", "Viable"
    ELIGIBLE_POA = "ELIGIBLE_POA", "Habilitado para programación"
    SENT_POA = "SENT_POA", "Enviado a SISPOA"
    NOT_VIABLE = "NOT_VIABLE", "No viable"
    ARCHIVED = "ARCHIVED", "Archivado"

class RM115Typology(models.TextChoices):
    I = "I", "Desarrollo Empresarial Productivo"
    II = "II", "Apoyo al Desarrollo Productivo"
    III = "III", "Desarrollo Social"
    IV = "IV", "Fortalecimiento Institucional"
    V = "V", "Investigación y Desarrollo Tecnológico"

class Project(UUIDTimeStampedModel):
    code = models.CharField(max_length=40, unique=True)
    official_name = models.CharField(max_length=500)
    short_name = models.CharField(max_length=160, blank=True)
    management_year = models.PositiveSmallIntegerField()
    status = models.CharField(max_length=30, choices=ProjectStatus.choices, default=ProjectStatus.REGISTERED)
    rm115_typology = models.CharField(max_length=4, choices=RM115Typology.choices, blank=True)
    sector = models.ForeignKey(CatalogItem, null=True, blank=True, on_delete=models.PROTECT, related_name="sector_projects")
    subsector = models.ForeignKey(CatalogItem, null=True, blank=True, on_delete=models.PROTECT, related_name="subsector_projects")
    project_class = models.CharField(max_length=120, blank=True)
    source_kind = models.CharField(max_length=80, blank=True)
    requesting_unit = models.ForeignKey(OrganizationalUnit, null=True, blank=True, on_delete=models.PROTECT, related_name="requested_projects")
    formulating_unit = models.ForeignKey(OrganizationalUnit, null=True, blank=True, on_delete=models.PROTECT, related_name="formulated_projects")
    responsible = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="responsible_projects")
    problem_statement = models.TextField(blank=True)
    general_objective = models.TextField(blank=True)
    location_description = models.TextField(blank=True)
    district_code = models.CharField(max_length=40, blank=True)
    community_name = models.CharField(max_length=255, blank=True)
    geom = models.GeometryField(srid=32719, null=True, blank=True)
    estimated_budget = models.DecimalField(max_digits=18, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(Decimal("0"))])
    approved_budget = models.DecimalField(max_digits=18, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(Decimal("0"))])
    currency = models.CharField(max_length=3, default="BOB")
    readiness_score = models.DecimalField(max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    eligible_for_poa = models.BooleanField(default=False)
    viability_expiration_date = models.DateField(null=True, blank=True)
    external_codes = models.JSONField(default=dict, blank=True)
    tags = models.JSONField(default=list, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["status", "management_year"])]

    def __str__(self):
        return f"{self.code} - {self.official_name}"

class ProjectComponent(UUIDTimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="components")
    code = models.CharField(max_length=50)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    physical_target = models.DecimalField(max_digits=18, decimal_places=4, null=True, blank=True)
    unit = models.CharField(max_length=50, blank=True)
    budget = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["project", "code"], name="uniq_component_code")]
        ordering = ["order", "code"]

class BeneficiaryGroup(UUIDTimeStampedModel, SourceTrackedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="beneficiary_groups")
    group_type = models.CharField(max_length=30, choices=[("DIRECT", "Directo"), ("INDIRECT", "Indirecto")])
    description = models.CharField(max_length=255)
    quantity = models.PositiveIntegerField(default=0)
    unit = models.CharField(max_length=50, default="personas")
    methodology = models.TextField(blank=True)

class ProjectAlternative(UUIDTimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="alternatives")
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=255)
    description = models.TextField()
    estimated_cost = models.DecimalField(max_digits=18, decimal_places=2, null=True, blank=True)
    selected = models.BooleanField(default=False)
    selection_justification = models.TextField(blank=True)

class ReformulationRequest(UUIDTimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="reformulation_requests")
    requested_by_system = models.CharField(max_length=50, default="SISPOA")
    reason = models.TextField()
    proposed_budget = models.DecimalField(max_digits=18, decimal_places=2, null=True, blank=True)
    status = models.CharField(max_length=30, default="OPEN")
    resolved_at = models.DateTimeField(null=True, blank=True)
