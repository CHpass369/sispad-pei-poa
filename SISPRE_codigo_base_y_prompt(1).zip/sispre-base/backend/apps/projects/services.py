from decimal import Decimal
from django.db import transaction
from .models import ProjectStatus, RM115Typology

CLASSIFICATION_RULES = {
    "PUENTE": RM115Typology.II,
    "CAMINO": RM115Typology.II,
    "RIEGO": RM115Typology.II,
    "POZO": RM115Typology.III,
    "AGUA": RM115Typology.III,
    "ALCANTARILLADO": RM115Typology.III,
    "TINGLADO": RM115Typology.III,
    "UNIDAD EDUCATIVA": RM115Typology.III,
    "MURO": RM115Typology.III,
    "SOFTWARE": RM115Typology.IV,
    "SISTEMA": RM115Typology.IV,
    "INVESTIGACIÓN": RM115Typology.V,
}

def suggest_typology(project):
    text = f"{project.official_name} {project.project_class}".upper()
    for keyword, typology in CLASSIFICATION_RULES.items():
        if keyword in text:
            return typology
    return RM115Typology.III

@transaction.atomic
def calculate_readiness(project):
    weights = {
        "identity": Decimal("10"),
        "alignment": Decimal("10"),
        "location": Decimal("10"),
        "itcp": Decimal("20"),
        "tdr": Decimal("10"),
        "edtp": Decimal("25"),
        "documents": Decimal("5"),
        "approvals": Decimal("10"),
    }
    score = Decimal("0")
    if project.official_name and project.management_year and project.responsible_id:
        score += weights["identity"]
    if project.problem_statement and project.general_objective and project.rm115_typology:
        score += weights["alignment"]
    if project.geom and project.district_code:
        score += weights["location"]
    if hasattr(project, "itcp"):
        conditions = project.itcp.conditions.all()
        if conditions.exists():
            resolved = conditions.filter(status__in=["COMPLIES", "APPROVED", "NOT_APPLICABLE"]).count()
            score += weights["itcp"] * Decimal(resolved) / Decimal(conditions.count())
    if hasattr(project, "tdr") and project.tdr.estimated_budget is not None:
        score += weights["tdr"]
    if hasattr(project, "edtp"):
        sections = project.edtp.sections.filter(required=True)
        if sections.exists():
            score += weights["edtp"] * Decimal(sections.filter(status="APPROVED").count()) / Decimal(sections.count())
    if project.documents.exists():
        score += weights["documents"]
    if project.approvals.filter(status="APPROVED").exists():
        score += weights["approvals"]
    project.readiness_score = min(score, Decimal("100"))
    project.eligible_for_poa = (
        project.status in [ProjectStatus.EDTP_APPROVED, ProjectStatus.VIABLE]
        and project.readiness_score >= Decimal("90")
        and not project.observations.filter(status="OPEN", severity="CRITICAL").exists()
    )
    if project.eligible_for_poa:
        project.status = ProjectStatus.ELIGIBLE_POA
    project.save(update_fields=["readiness_score", "eligible_for_poa", "status", "updated_at"])
    return project.readiness_score
