from rest_framework import serializers
from .models import Project, ProjectComponent, BeneficiaryGroup, ProjectAlternative, ReformulationRequest

class ProjectComponentSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectComponent
        fields = "__all__"

class BeneficiaryGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = BeneficiaryGroup
        fields = "__all__"

class ProjectAlternativeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectAlternative
        fields = "__all__"

class ProjectSerializer(serializers.ModelSerializer):
    components = ProjectComponentSerializer(many=True, read_only=True)
    beneficiary_groups = BeneficiaryGroupSerializer(many=True, read_only=True)
    alternatives = ProjectAlternativeSerializer(many=True, read_only=True)
    geometry_geojson = serializers.SerializerMethodField()

    class Meta:
        model = Project
        fields = "__all__"
        read_only_fields = ("id", "readiness_score", "eligible_for_poa", "created_at", "updated_at")

    def get_geometry_geojson(self, obj):
        return __import__('json').loads(obj.geom.transform(4326, clone=True).geojson) if obj.geom else None

    def validate(self, attrs):
        if attrs.get("approved_budget") is not None and attrs.get("approved_budget") < 0:
            raise serializers.ValidationError("El presupuesto aprobado no puede ser negativo")
        return attrs

class ReformulationRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReformulationRequest
        fields = "__all__"
