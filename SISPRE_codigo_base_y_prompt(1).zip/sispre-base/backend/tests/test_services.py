import pytest
from django.contrib.auth import get_user_model
from apps.projects.models import Project
from apps.preinvestment.services import initialize_itcp

@pytest.mark.django_db
def test_initialize_itcp_creates_nine_conditions():
    user = get_user_model().objects.create_user(username="formulador", password="test")
    project = Project.objects.create(code="SISPRE-2026-000001", official_name="CONST. MURO", management_year=2026, responsible=user)
    itcp = initialize_itcp(project, user)
    assert itcp.conditions.count() == 9
    assert hasattr(project, "tdr")
