import pytest
from django.contrib.auth import get_user_model
from apps.projects.models import Project
from apps.projects.services import suggest_typology

@pytest.mark.django_db
def test_bridge_is_type_ii():
    user = get_user_model().objects.create_user(username="u")
    project = Project(code="SISPRE-2026-2", official_name="CONST. PUENTE VEHICULAR", management_year=2026, responsible=user)
    assert suggest_typology(project) == "II"
