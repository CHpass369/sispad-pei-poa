# Prompt maestro para implementar SISPRE

Actúa como arquitecto de software, analista de inversión pública, desarrollador senior full-stack y especialista SIG. Debes completar y endurecer el repositorio **SISPRE — Sistema de Información de Preinversión** sin alterar sus principios de arquitectura.

## 1. Objetivo institucional

Construir un sistema independiente que gestione las iniciativas de inversión municipal antes de SISPOA y que posteriormente se integre con los demás sistemas del Ciclo del Proyecto:

```text
SIS PAD–PEI → SISPRE → SISPOA → SISPRO → SISFIN / Seguimiento y Evaluación
```

SISPRE debe registrar, preparar, evaluar, revisar, aprobar y archivar proyectos de preinversión; generar ITCP y EDTP; mantener un Banco Municipal de Proyectos Viables; y transferir a SISPOA únicamente proyectos técnicamente habilitados.

## 2. Normativa y estructura documental

Implementa la Resolución Ministerial N.º 115 — Reglamento Básico de Preinversión como reglas y plantillas configurables, no como texto rígido.

### ITCP — condiciones previas

Debe contemplar como mínimo:

1. Justificación de la iniciativa:
   - principios y derechos constitucionales;
   - planificación nacional, sectorial y territorial;
   - competencias institucionales;
   - priorización sectorial.
2. Idea del proyecto:
   - necesidad, problema u oportunidad;
   - objetivos;
   - beneficios y beneficiarios;
   - alternativas;
   - localización.
3. Compromiso social documentado.
4. Derecho propietario.
5. Afectación de derechos de vía y terceros.
6. Posibles impactos ambientales.
7. Riesgos de desastre y adaptación al cambio climático.
8. Otros aspectos según complejidad.
9. Conclusiones y recomendaciones.

El ITCP debe incluir o vincular obligatoriamente la Parte B:

- Términos de Referencia del EDTP.
- Presupuesto referencial del EDTP con memorias de cálculo.

### EDTP

Genera un índice dinámico por tipología RM 115:

- Tipo I: Desarrollo Empresarial Productivo.
- Tipo II: Apoyo al Desarrollo Productivo.
- Tipo III: Desarrollo Social.
- Tipo IV: Fortalecimiento Institucional.
- Tipo V: Investigación y Desarrollo Tecnológico.

El contenido debe activar/desactivar capítulos según tipología, perfil sectorial y complejidad. Para proyectos de infraestructura debe manejar estudios básicos, memorias de cálculo, cómputos métricos, APU, presupuesto, cronograma, planos y especificaciones.

## 3. Principios obligatorios

1. El documento no es la base de datos; se genera desde un expediente estructurado.
2. Un dato se registra una sola vez y se reutiliza.
3. Toda cifra debe registrar fuente, fecha de corte y responsable.
4. Toda aprobación y observación debe ser trazable.
5. No permitir viabilidad si existe una condición crítica pendiente.
6. No permitir cambios silenciosos después de una aprobación; crear una nueva versión.
7. Las integraciones se realizan por API/eventos; nunca por escritura directa a otra base.
8. Usar UUID como identificador canónico.
9. Mantener códigos externos para SIS PAD–PEI, SISPOA, SISPRO y SISFIN.
10. Implementar seguridad por roles, unidad organizacional y etapa del flujo.

## 4. Stack obligatorio

- Backend: Python 3.13, Django 6, GeoDjango, Django REST Framework.
- Frontend: Angular 22, Angular Material, MapLibre.
- Base de datos: PostgreSQL 17 + PostGIS 3.6.
- Asincronía: Celery + Redis.
- Documentos: docxtpl + LibreOffice headless; archivos en MinIO/S3.
- Geo: GeoServer 3, WMS/WFS/OGC API cuando corresponda.
- API: REST versionada y OpenAPI.
- Despliegue: Docker Compose en desarrollo y manifiestos preparados para producción.

## 5. Módulos

### A. Catálogos y seguridad

- usuarios, roles, cargos y unidades;
- sectores, subsectores, clases de proyecto;
- tipologías RM 115;
- distritos, OTB y comunidades;
- fuentes de financiamiento;
- unidades de medida;
- tipos documentales;
- matrices normativas versionadas.

### B. Iniciativas y admisibilidad

- registro georreferenciado;
- fuente de iniciativa;
- competencia municipal;
- alineamiento PAD–PEI;
- detección de duplicidad espacial y temática;
- decisión: admitida, observada, rechazada o duplicada.

### C. ITCP

- asistente por secciones;
- matriz de condiciones previas;
- evidencias y responsables;
- semáforo de viabilidad;
- conclusiones controladas;
- generación DOCX/PDF;
- circuito de revisión y aprobación MAE.

### D. TDR y presupuesto del EDTP

- actividades, productos, personal, plazo y presupuesto;
- perfiles sectoriales: muro, puente, pozo, infraestructura educativa, vial, agua y saneamiento, etc.;
- memorias de cálculo del presupuesto del estudio.

### E. EDTP

- secciones dinámicas;
- diagnóstico geoespacial;
- oferta, demanda y balance;
- alternativas;
- tamaño y localización;
- ingeniería y estudios técnicos;
- ambiente, riesgos y resiliencia;
- costos, operación y mantenimiento;
- evaluación según tipología;
- sensibilidad, financiamiento y cronograma;
- conclusiones y viabilidad.

### F. Banco de proyectos

- iniciativas;
- proyectos en preinversión;
- proyectos viables;
- madurez;
- vigencia de estudios y precios;
- habilitación para programación;
- devolución y reformulación solicitada por SISPOA.

### G. Documentos y control de versiones

- archivo editable y firmado;
- hash SHA-256;
- metadatos;
- versión;
- expediente completo;
- generación de paquete de transferencia.

### H. Interoperabilidad

- API de consulta y creación;
- referencias externas;
- patrón Outbox;
- idempotencia;
- webhooks firmados opcionales;
- paquete JSON + GeoJSON + documentos para SISPOA/SISPRO.

## 6. Roles mínimos

- Administrador del sistema.
- Administrador normativo.
- Registrador de iniciativas.
- Formulador técnico.
- Formulador económico.
- Especialista SIG.
- Revisor territorial.
- Revisor de riesgos.
- Revisor ambiental.
- Revisor legal.
- Jefatura de Preinversión.
- Dirección.
- Secretaría Municipal.
- MAE.
- Consulta y auditoría.

Implementa permisos por acción y por proyecto; un usuario solo debe modificar proyectos de su unidad o aquellos asignados formalmente.

## 7. Reglas de negocio críticas

- `ITCP_APROBADO` requiere:
  - condiciones críticas resueltas;
  - TDR creado;
  - presupuesto referencial del EDTP;
  - revisión legal;
  - aprobación MAE.
- `EDTP_APROBADO` requiere:
  - secciones obligatorias aprobadas;
  - presupuesto consistente;
  - cronograma consistente;
  - estudios requeridos aprobados;
  - evaluación compatible con tipología;
  - plan de operación y mantenimiento cuando corresponda;
  - instrumento de aprobación.
- `HABILITADO_PARA_POA` requiere:
  - EDTP aprobado;
  - presupuesto vigente;
  - madurez mínima parametrizable;
  - inexistencia de observaciones críticas abiertas.
- Si SISPOA solicita reducción de presupuesto, crear solicitud de reformulación; no alterar el EDTP aprobado.

## 8. Validaciones automáticas

- distrito/OTB frente a geometría;
- predios afectados y derecho propietario;
- nombres de otros proyectos dentro del contenido;
- beneficiarios contradictorios;
- componentes incompatibles con la clase de proyecto;
- presupuesto vs. financiamiento vs. cronograma;
- capítulos ausentes;
- anexos referidos pero no cargados;
- fuentes sin fecha o identificación;
- O&M igual a cero sin justificación;
- duplicidad espacial y similitud de nombre.

## 9. API mínima

Implementa y documenta:

```text
POST   /api/v1/projects/
GET    /api/v1/projects/{uuid}/
POST   /api/v1/projects/{uuid}/classify/
POST   /api/v1/projects/{uuid}/initialize-itcp/
POST   /api/v1/projects/{uuid}/calculate-readiness/
POST   /api/v1/projects/{uuid}/generate-document/
POST   /api/v1/projects/{uuid}/initialize-edtp/
GET    /api/v1/projects/{uuid}/transfer-package/
POST   /api/v1/projects/{uuid}/request-reformulation/
GET    /api/v1/projects/eligible-for-poa/
```

Agregar endpoints CRUD para condiciones, secciones, estudios, costos, financiamiento, documentos, revisiones, observaciones y aprobaciones.

## 10. Calidad y entrega

Para cada incremento:

1. Escribir migraciones explícitas.
2. Crear pruebas unitarias y de API.
3. Validar permisos.
4. Actualizar OpenAPI.
5. Crear semillas idempotentes.
6. Documentar decisiones con ADR.
7. Mantener cobertura mínima del 80 % en reglas críticas.
8. Ejecutar linters y análisis de seguridad.
9. No introducir datos normativos inventados; todo catálogo legal debe ser parametrizable y revisable.
10. Entregar cambios pequeños, compilables y con instrucciones de despliegue.

## 11. Primera iteración requerida

Completa en este orden:

1. Migraciones y semillas.
2. Autenticación, roles y permisos.
3. CRUD de proyectos y geometría.
4. Clasificación RM 115.
5. ITCP y condiciones previas.
6. TDR y presupuesto referencial.
7. Generación DOCX del ITCP.
8. EDTP dinámico y estudios.
9. Generación DOCX del EDTP.
10. Banco de proyectos viables.
11. API de transferencia.
12. Pruebas end-to-end.

No reemplaces el modelo estructurado por campos de texto genéricos. Los campos narrativos pueden existir, pero siempre deben complementarse con datos normalizados, evidencias, estados, fuente y responsable.
