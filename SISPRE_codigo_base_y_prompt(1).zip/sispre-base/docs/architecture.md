# Arquitectura de SISPRE

## Contexto

SISPRE es un bounded context independiente para preinversión. Opera antes de SISPOA y entrega proyectos viables. Mantiene su base de datos y repositorio documental propios.

```mermaid
C4Context
    title Contexto del Ciclo del Proyecto
    Person(user, "Servidor público")
    System(pad, "SIS PAD–PEI", "Resultados y alineamiento")
    System(sispre, "SISPRE", "Preinversión y viabilidad")
    System(poa, "SISPOA", "Programación y presupuesto")
    System(pro, "SISPRO", "Contratación y ejecución")
    System(fin, "SISFIN", "Ejecución financiera")
    Rel(pad, sispre, "objetivos e indicadores")
    Rel(user, sispre, "formula y revisa")
    Rel(sispre, poa, "proyecto viable")
    Rel(poa, pro, "proyecto programado")
    Rel(pro, fin, "solicitudes y devengados")
```

## Componentes

- **API de dominio:** proyectos, ITCP, TDR, EDTP, documentos y flujos.
- **Motor de reglas:** admisibilidad, completitud, viabilidad y madurez.
- **Motor documental:** plantillas DOCX versionadas y conversión a PDF.
- **Componente geoespacial:** geometrías, cruces y servicios GeoServer.
- **Integración:** API, referencias externas y Outbox.
- **Auditoría:** acciones, transiciones, cambios y descargas.

## Decisiones

- Monolito modular inicial para reducir complejidad operacional.
- Separación fuerte por apps de Django y contratos de servicio.
- API REST versionada.
- UUID como identidad canónica.
- Eventual extracción de generación documental e integración como servicios independientes.
