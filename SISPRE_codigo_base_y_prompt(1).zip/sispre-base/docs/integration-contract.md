# Contrato de integración

## Patrón

- API REST síncrona para consulta y comandos puntuales.
- Outbox para eventos confiables.
- Clave de idempotencia para mensajes entrantes.
- Firma HMAC para webhooks cuando se habiliten.

## Evento: project.preinvestment.approved

```json
{
  "event_id": "uuid",
  "event_type": "project.preinvestment.approved",
  "occurred_at": "2026-08-03T12:00:00-04:00",
  "project_id": "uuid",
  "project_code": "SISPRE-2026-000001",
  "payload": {
    "official_name": "CONST. ...",
    "rm115_typology": "III",
    "viability": "VIABLE",
    "approved_budget": "850000.00",
    "currency": "BOB",
    "geometry": {"type": "Point", "coordinates": [-66.0, -17.4]},
    "components": [],
    "documents": []
  }
}
```

## Paquete para SISPOA

Debe ser de solo lectura para SISPOA. Cualquier cambio de alcance se solicita como reformulación y retorna a SISPRE.
