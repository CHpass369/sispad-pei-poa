# Modelo de dominio

```mermaid
erDiagram
    PROJECT ||--o{ PROJECT_COMPONENT : contiene
    PROJECT ||--o{ BENEFICIARY_GROUP : beneficia
    PROJECT ||--o{ PROJECT_ALTERNATIVE : evalua
    PROJECT ||--|| ITCP : tiene
    ITCP ||--o{ ITCP_CONDITION : verifica
    PROJECT ||--|| TDR : define
    TDR ||--o{ TDR_ACTIVITY : contiene
    TDR ||--o{ TDR_PRODUCT : entrega
    TDR ||--o{ TDR_PERSONNEL : requiere
    PROJECT ||--|| EDTP : desarrolla
    EDTP ||--o{ EDTP_SECTION : estructura
    EDTP ||--o{ TECHNICAL_STUDY : respalda
    EDTP ||--o{ COST_ITEM : presupuesta
    EDTP ||--o{ FINANCING_SOURCE : financia
    PROJECT ||--o{ DOCUMENT : archiva
    DOCUMENT ||--o{ DOCUMENT_VERSION : versiona
    PROJECT ||--o{ REVIEW : revisa
    REVIEW ||--o{ OBSERVATION : observa
    PROJECT ||--o{ APPROVAL : aprueba
    PROJECT ||--o{ EXTERNAL_REFERENCE : integra
```

## Identidad

`Project.id` es UUID y no cambia. `code` es legible y único. Los códigos de sistemas externos se almacenan en `ExternalReference`.

## Versionado

ITCP, TDR y EDTP poseen número de versión. Una aprobación cierra la versión. Toda reformulación debe crear una nueva versión lógica y preservar los documentos anteriores.
