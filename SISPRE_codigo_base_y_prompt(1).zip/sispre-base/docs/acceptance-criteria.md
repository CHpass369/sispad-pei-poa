# Criterios de aceptación

## ITCP

- Se genera desde datos estructurados.
- Incluye las nueve condiciones previas y referencia a TDR/presupuesto.
- No se aprueba con condiciones críticas abiertas.
- Conserva responsables, fuentes, evidencias y versión.

## EDTP

- Índice depende de tipología y perfil sectorial.
- Secciones obligatorias no pueden omitirse sin justificación de no aplicabilidad.
- Presupuesto, cronograma y financiamiento cuadran.
- Estudios técnicos registran autor, matrícula, versión y aprobación.
- Documento final se genera en DOCX y puede convertirse a PDF.

## Integración

- Proyecto viable expone paquete completo.
- El envío es idempotente.
- Se conserva referencia del sistema receptor.
- Una devolución de SISPOA crea solicitud de reformulación, no altera la versión aprobada.
