export interface Paginated<T> { count: number; next: string|null; previous: string|null; results: T[]; }
export interface ComponentItem { id:string; code:string; name:string; description:string; physical_target:string|null; unit:string; budget:string; }
export interface Beneficiary { id:string; group_type:'DIRECT'|'INDIRECT'; description:string; quantity:number; unit:string; }
export interface Project {
  id:string; code:string; official_name:string; short_name:string; management_year:number; status:string;
  rm115_typology:string; project_class:string; district_code:string; community_name:string;
  problem_statement:string; general_objective:string; approved_budget:string|null; estimated_budget:string|null;
  readiness_score:string; eligible_for_poa:boolean; geometry_geojson:Record<string, unknown>|null;
  components:ComponentItem[]; beneficiary_groups:Beneficiary[];
}
