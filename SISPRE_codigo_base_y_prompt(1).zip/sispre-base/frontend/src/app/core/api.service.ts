import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Project, Paginated } from '../models/project';
@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private base = '/api/v1';
  listProjects(params: Record<string,string> = {}): Observable<Paginated<Project>> { return this.http.get<Paginated<Project>>(`${this.base}/projects/`, { params }); }
  getProject(id: string): Observable<Project> { return this.http.get<Project>(`${this.base}/projects/${id}/`); }
  classify(id: string): Observable<unknown> { return this.http.post(`${this.base}/projects/${id}/classify/`, { accept: true }); }
  initializeItcp(id: string): Observable<unknown> { return this.http.post(`${this.base}/projects/${id}/initialize-itcp/`, {}); }
  initializeEdtp(id: string): Observable<unknown> { return this.http.post(`${this.base}/projects/${id}/initialize-edtp/`, {}); }
  readiness(id: string): Observable<{score:number; eligible_for_poa:boolean}> { return this.http.post<{score:number; eligible_for_poa:boolean}>(`${this.base}/projects/${id}/calculate-readiness/`, {}); }
  generate(id: string, documentType: 'ITCP'|'EDTP'): Observable<unknown> { return this.http.post(`${this.base}/projects/${id}/generate-document/`, { document_type: documentType }); }
}
