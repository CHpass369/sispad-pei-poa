import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { ApiService } from '../../core/api.service';
import { Project } from '../../models/project';
@Component({selector:'app-project-list',standalone:true,imports:[CommonModule,RouterLink,MatTableModule,MatButtonModule,MatCardModule],template:`
<div class="container"><div style="display:flex;align-items:center"><h1>Proyectos</h1><span style="flex:1"></span><button mat-flat-button>Registrar iniciativa</button></div>
<mat-card><table mat-table [dataSource]="projects" class="full-width">
<ng-container matColumnDef="code"><th mat-header-cell *matHeaderCellDef>Código</th><td mat-cell *matCellDef="let p">{{p.code}}</td></ng-container>
<ng-container matColumnDef="name"><th mat-header-cell *matHeaderCellDef>Proyecto</th><td mat-cell *matCellDef="let p"><a [routerLink]="['/projects',p.id]">{{p.official_name}}</a></td></ng-container>
<ng-container matColumnDef="status"><th mat-header-cell *matHeaderCellDef>Estado</th><td mat-cell *matCellDef="let p">{{p.status}}</td></ng-container>
<ng-container matColumnDef="readiness"><th mat-header-cell *matHeaderCellDef>Madurez</th><td mat-cell *matCellDef="let p">{{p.readiness_score}}%</td></ng-container>
<tr mat-header-row *matHeaderRowDef="columns"></tr><tr mat-row *matRowDef="let row; columns:columns"></tr></table></mat-card></div>`})
export class ProjectListComponent implements OnInit { private api=inject(ApiService); projects:Project[]=[]; columns=['code','name','status','readiness']; ngOnInit(){this.api.listProjects().subscribe(r=>this.projects=r.results);} }
