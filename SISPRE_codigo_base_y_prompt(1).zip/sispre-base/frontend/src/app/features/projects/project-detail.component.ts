import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatTabsModule } from '@angular/material/tabs';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ApiService } from '../../core/api.service';
import { Project } from '../../models/project';
@Component({selector:'app-project-detail',standalone:true,imports:[CommonModule,MatCardModule,MatButtonModule,MatTabsModule,MatProgressBarModule],template:`
<div class="container" *ngIf="project as p"><h1>{{p.official_name}}</h1><p>{{p.code}} · {{p.status}} · Tipo {{p.rm115_typology || 'sin clasificar'}}</p>
<mat-progress-bar mode="determinate" [value]="+p.readiness_score"></mat-progress-bar><p>Madurez: {{p.readiness_score}}%</p>
<div style="display:flex;gap:8px;flex-wrap:wrap"><button mat-stroked-button (click)="classify()">Clasificar RM 115</button><button mat-stroked-button (click)="initItcp()">Iniciar ITCP</button><button mat-stroked-button (click)="initEdtp()">Iniciar EDTP</button><button mat-flat-button (click)="generate('ITCP')">Generar ITCP</button><button mat-flat-button (click)="generate('EDTP')">Generar EDTP</button></div>
<mat-tab-group style="margin-top:20px"><mat-tab label="Resumen"><mat-card style="margin-top:16px"><mat-card-content><h3>Problema</h3><p>{{p.problem_statement || 'Pendiente'}}</p><h3>Objetivo</h3><p>{{p.general_objective || 'Pendiente'}}</p></mat-card-content></mat-card></mat-tab>
<mat-tab label="Componentes"><div *ngFor="let c of p.components" style="padding:12px 0"><strong>{{c.code}} {{c.name}}</strong> — Bs {{c.budget}}</div></mat-tab>
<mat-tab label="Beneficiarios"><div *ngFor="let b of p.beneficiary_groups" style="padding:12px 0">{{b.group_type}}: {{b.quantity}} {{b.unit}} — {{b.description}}</div></mat-tab>
<mat-tab label="ITCP"><p style="padding:16px">La matriz de condiciones previas se gestiona desde la API base. Implementar wizard sectorial en la siguiente iteración.</p></mat-tab>
<mat-tab label="EDTP"><p style="padding:16px">El espacio de trabajo usa secciones dinámicas por tipología.</p></mat-tab></mat-tab-group></div>`})
export class ProjectDetailComponent implements OnInit { private api=inject(ApiService); private route=inject(ActivatedRoute); project?:Project; id=''; ngOnInit(){this.id=this.route.snapshot.paramMap.get('id')!; this.reload();} reload(){this.api.getProject(this.id).subscribe(p=>this.project=p);} classify(){this.api.classify(this.id).subscribe(()=>this.reload());} initItcp(){this.api.initializeItcp(this.id).subscribe(()=>this.reload());} initEdtp(){this.api.initializeEdtp(this.id).subscribe(()=>this.reload());} generate(t:'ITCP'|'EDTP'){this.api.generate(this.id,t).subscribe();} }
