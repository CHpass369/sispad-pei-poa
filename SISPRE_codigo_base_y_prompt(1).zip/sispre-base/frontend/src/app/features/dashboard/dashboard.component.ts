import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { ApiService } from '../../core/api.service';
@Component({ selector:'app-dashboard', standalone:true, imports:[CommonModule, MatCardModule], template:`
<div class="container"><h1>Banco Municipal de Proyectos</h1><div class="grid grid-4">
<mat-card><mat-card-header><mat-card-title>Iniciativas</mat-card-title></mat-card-header><mat-card-content><h2>{{ total }}</h2></mat-card-content></mat-card>
<mat-card><mat-card-header><mat-card-title>En preinversión</mat-card-title></mat-card-header><mat-card-content><h2>{{ inPreinvestment }}</h2></mat-card-content></mat-card>
<mat-card><mat-card-header><mat-card-title>Viables</mat-card-title></mat-card-header><mat-card-content><h2>{{ viable }}</h2></mat-card-content></mat-card>
<mat-card><mat-card-header><mat-card-title>Habilitados POA</mat-card-title></mat-card-header><mat-card-content><h2>{{ eligible }}</h2></mat-card-content></mat-card>
</div></div>` })
export class DashboardComponent implements OnInit {
  private api=inject(ApiService); total=0; inPreinvestment=0; viable=0; eligible=0;
  ngOnInit(){ this.api.listProjects().subscribe(r=>{this.total=r.count; this.inPreinvestment=r.results.filter(p=>p.status.includes('ITCP')||p.status.includes('EDTP')).length; this.viable=r.results.filter(p=>p.status==='VIABLE').length; this.eligible=r.results.filter(p=>p.eligible_for_poa).length;}); }
}
