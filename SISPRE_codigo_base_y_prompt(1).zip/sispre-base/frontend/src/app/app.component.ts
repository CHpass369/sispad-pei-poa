import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
@Component({
  selector: 'app-root', standalone: true,
  imports: [RouterOutlet, RouterLink, MatToolbarModule, MatButtonModule, MatIconModule],
  template: `<mat-toolbar><mat-icon>account_tree</mat-icon><span style="margin-left:8px">SISPRE</span><span style="flex:1"></span><a mat-button routerLink="/">Panel</a><a mat-button routerLink="/projects">Proyectos</a></mat-toolbar><router-outlet />`
})
export class AppComponent {}
