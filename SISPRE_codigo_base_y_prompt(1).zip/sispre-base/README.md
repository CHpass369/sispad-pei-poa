# SISPRE — Sistema de Información de Preinversión

Base de implementación para gestionar el ciclo de preinversión municipal: iniciativas, admisibilidad, ITCP, TDR y presupuesto referencial del EDTP, formulación del EDTP, estudios de ingeniería, evaluación, revisión, aprobación, banco de proyectos viables e interoperabilidad posterior con SISPOA, SISPRO, SIS PAD–PEI y SISFIN.

## Alcance de esta base

La solución incluye:

- Backend Django/GeoDjango + Django REST Framework.
- PostgreSQL/PostGIS.
- Frontend Angular + Angular Material + MapLibre.
- Redis/Celery para generación documental y tareas asíncronas.
- Repositorio documental local o S3/MinIO.
- Plantillas DOCX para ITCP y EDTP.
- Motor inicial de reglas normativas, madurez y consistencia.
- API versionada y patrón Outbox para integraciones.
- Docker Compose para desarrollo.
- Pruebas base y contrato OpenAPI.

> Esta entrega es una base arquitectónica ejecutable y extensible. Antes de producción se deben completar migraciones versionadas, pruebas sectoriales, plantillas institucionales definitivas, hardening, firma digital y validación jurídica de los flujos.

## Flujo funcional

```mermaid
flowchart LR
    A[PAD–PEI / Demanda social] --> B[SISPRE: iniciativa]
    B --> C[Admisibilidad]
    C --> D[ITCP]
    D --> E[TDR + presupuesto EDTP]
    E --> F[EDTP]
    F --> G[Viabilidad]
    G --> H[Banco de proyectos viables]
    H --> I[SISPOA]
    I --> J[SISPRO]
    J --> K[SISFIN / seguimiento]
```

## Inicio rápido

```bash
cp .env.example .env
docker compose up --build
```

Servicios:

- Frontend: `http://localhost:4200`
- API: `http://localhost:8000/api/v1/`
- OpenAPI: `http://localhost:8000/api/schema/`
- Swagger: `http://localhost:8000/api/docs/`
- MinIO: `http://localhost:9001`
- GeoServer: `http://localhost:8080/geoserver`

En desarrollo, el contenedor genera las migraciones iniciales al arrancar. Antes de producción, se deben congelar y versionar en Git.

Crear usuario administrador:

```bash
docker compose exec backend python manage.py createsuperuser
docker compose exec backend python manage.py seed_sispre
```

## Estructura

```text
backend/     API, dominio, reglas, documentos e integraciones
frontend/    interfaz Angular
infra/       Nginx y configuración auxiliar
docs/        arquitectura, modelo, API y criterios
```

## Regla de integración

- SISPRE define **qué proyecto es viable** y consolida su expediente técnico.
- SISPOA define **cuándo y con qué recursos se programa**.
- SISPRO administra **contratación, ejecución y cierre**.
- Los sistemas se integran por API/eventos, nunca mediante escritura directa entre bases de datos.
